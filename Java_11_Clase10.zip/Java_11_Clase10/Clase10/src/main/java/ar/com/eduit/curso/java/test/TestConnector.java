/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import java.sql.ResultSet;
import java.time.LocalTime;

/**
 *
 * @author Joaquin
 */
public class TestConnector {
    public static void main(String[]args){
        int inicio=LocalTime.now().getNano()/1000000000;
        try(ResultSet rs=Connector
                .getConnection()
                .createStatement()
                .executeQuery("select version()")){
            if(rs.next()){
                System.out.println("Se conectó a "+rs.getString(1));
            }else{
                System.out.println("No se pudo conectar a la Base de Datos");
            }
        }catch(Exception e){
            System.out.println("No se pudo conectar a la Base de datos");
            System.out.println(e);
        }
        int fin=LocalTime.now().getNano()/1000000000;
        System.out.println("Tiempo de conexión: "+(fin-inicio));
    }
}
