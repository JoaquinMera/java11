/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;

/**
 *
 * @author Joaquin
 */
public class TestRepository {
    public static void main(String[]args){
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        Curso curso=new Curso("Java","Rios",Dia.MARTES,Turno.NOCHE);
        cr.save(curso);
        System.out.println(curso);
        
        System.out.println("*********************************");
        cr.getLikeTitulo("ja").forEach(System.out::println);
        
        System.out.println("**************************");
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
        Alumno alumno=new Alumno("Nicolas","Leon",41,1);
        ar.save(alumno);
        System.out.println(alumno);
    }
}
